package satou2_4;
class satou2_4
{
	public static void main(String[] args){
		int X;
		X = 7;
		System.out.println("変数Xの3倍は、" + X*3);
		int Y;
		Y = (X*3)/2;
		System.out.println("変数Xの3倍をさらに1/2にすると、" + Y);
		}
}