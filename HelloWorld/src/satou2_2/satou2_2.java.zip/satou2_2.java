package satou2_2;
class satou2_2{
	public static void main(String[] args) {
		String hello = "Hello";
		String world = "Wolrd";
		System.out.println(hello + "," + world);
	}
}
